<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With, Cache-Control, cache-control, Pragma, Expires, *");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}
include_once __DIR__ . '/../../../config/db.php';
$db = (new Database())->getConnection();
$booking_id = $_GET['booking_id'] ?? null;
if (!$booking_id) { http_response_code(400); echo json_encode(['status'=>'error','message'=>'booking_id required']); exit; }
$stmt = $db->prepare("SELECT b.*, bd.guests, bd.country, bd.address, bd.additional_notes, bd.children, bd.extra_guest_charge, bd.extra_adults, bd.extra_children, p.transaction_id, p.amount as paid_amount, p.platform_fee as payment_platform_fee, p.gross_amount as payment_gross_amount FROM bookings b LEFT JOIN booking_details bd ON bd.booking_id = b.id LEFT JOIN payments p ON p.booking_id = b.id WHERE b.id = ? OR b.booking_id = ? LIMIT 1");
$stmt->execute([$booking_id, $booking_id]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$row) { http_response_code(404); echo json_encode(['status'=>'error','message'=>'not found']); exit; }
$row['children'] = intval($row['children'] ?? 0);
$row['children_count'] = $row['children'];
$row['extra_guest_charge'] = floatval($row['extra_guest_charge'] ?? 0);
$roomStmt = $db->prepare("SELECT r.* FROM booking_rooms br JOIN rooms_new r ON r.id = br.room_id WHERE br.booking_id = ?");
$roomStmt->execute([$row['id']]);
$rooms = $roomStmt->fetchAll(PDO::FETCH_ASSOC);
$row['rooms']=$rooms;
echo json_encode(['status'=>'success','booking'=>$row]);
?>