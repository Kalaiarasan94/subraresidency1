<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With, Cache-Control, cache-control, Pragma, Expires, *");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

include_once __DIR__ . '/../../config/db.php';
include_once __DIR__ . '/../../utils/Mailer.php';

$logFile = __DIR__ . '/../../logs/payment.log';
file_put_contents($logFile, "[" . date('Y-m-d H:i:s') . "] CRITICAL: create_order.php reached!\n", FILE_APPEND);

// Read input: expects { booking_id, amount, currency }
$input = json_decode(file_get_contents('php://input'), true);
file_put_contents($logFile, "[" . date('Y-m-d H:i:s') . "] CRITICAL: Input: " . json_encode($input) . "\n", FILE_APPEND);
if (!$input || empty($input['booking_id']) || empty($input['amount'])) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Invalid input']);
    exit;
}

$bookingId = $input['booking_id'];
$amount = intval(round(floatval($input['amount']) * 100)); // in paise
$currency = $input['currency'] ?? 'INR';

// Load keys from env file
$env = @parse_ini_file(__DIR__ . '/../../.env');
if (!$env) $env = [];
$key_id = $env['RAZORPAY_KEY_ID'] ?? '';
$key_secret = $env['RAZORPAY_KEY_SECRET'] ?? '';

if (!$key_id || !$key_secret) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Payment gateway not configured']);
    exit;
}

// Check for Debug Mail Flag
if (isset($env['DEBUG_MAIL_ON_ORDER']) && ($env['DEBUG_MAIL_ON_ORDER'] == 'true' || $env['DEBUG_MAIL_ON_ORDER'] == 1)) {
    $logFile = __DIR__ . '/../../logs/payment.log';
    file_put_contents($logFile, "[" . date('Y-m-d H:i:s') . "] DEBUG: Debug Mail Triggered for ID: $bookingId\n", FILE_APPEND);
    try {
        $database = new Database();
        $db = $database->getConnection();
        $stmt = $db->prepare("SELECT guest_email, guest_name, check_in_date, check_out_date FROM bookings WHERE booking_id = ?");
        $stmt->execute([$bookingId]);
        $booking = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($booking) {
            file_put_contents($logFile, "[" . date('Y-m-d H:i:s') . "] DEBUG: Sending Mail to " . $booking['guest_email'] . "\n", FILE_APPEND);
            Mailer::sendBookingConfirmation(
                $booking['guest_email'],
                $booking['guest_name'],
                $bookingId,
                $booking['check_in_date'],
                $booking['check_out_date'],
                floatval($input['amount'])
            );
        } else {
            file_put_contents($logFile, "[" . date('Y-m-d H:i:s') . "] DEBUG: No booking found for ID: $bookingId\n", FILE_APPEND);
        }
    } catch (Exception $e) {
        file_put_contents($logFile, "[" . date('Y-m-d H:i:s') . "] DEBUG ERROR: " . $e->getMessage() . "\n", FILE_APPEND);
    }
}

// Create order via Razorpay REST API
$payload = json_encode([
    'amount' => $amount,
    'currency' => $currency,
    'receipt' => $bookingId,
    'payment_capture' => 1
]);

$ch = curl_init('https://api.razorpay.com/v1/orders');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_USERPWD, $key_id . ':' . $key_secret);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_TIMEOUT, 15);

$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curl_err = curl_error($ch);
curl_close($ch);

file_put_contents($logFile, "[" . date('Y-m-d H:i:s') . "] RAZORPAY RESPONSE (HTTP $http_code): " . ($response ?: 'EMPTY') . " | cURL Error: " . ($curl_err ?: 'NONE') . "\n", FILE_APPEND);

if ($http_code >= 200 && $http_code < 300) {
    $resp = json_decode($response, true);
    echo json_encode(['status' => 'success', 'order' => $resp, 'key_id' => $key_id]);
} else {
    // If Razorpay test key authentication fails (e.g. HTTP 401 with invalid test keys), fallback to simulated order mode
    if ($http_code === 401 || empty($key_id) || strpos($key_id, 'rzp_test_') === 0) {
        $simOrder = [
            'id' => 'order_sim_' . substr(md5(uniqid($bookingId, true)), 0, 14),
            'entity' => 'order',
            'amount' => $amount,
            'amount_paid' => 0,
            'amount_due' => $amount,
            'currency' => $currency,
            'receipt' => $bookingId,
            'status' => 'created'
        ];
        file_put_contents($logFile, "[" . date('Y-m-d H:i:s') . "] NOTICE: Using simulated payment order fallback due to Razorpay HTTP $http_code auth response.\n", FILE_APPEND);
        echo json_encode([
            'status' => 'success',
            'order' => $simOrder,
            'key_id' => $key_id ?: 'rzp_test_simulated',
            'is_simulated' => true
        ]);
        exit;
    }

    http_response_code(500);
    $details = json_decode($response, true) ?: $response;
    echo json_encode([
        'status' => 'error',
        'message' => 'Failed to create order',
        'http_code' => $http_code,
        'details' => $details,
        'curl_error' => $curl_err
    ]);
}
?>